<?php
include_once "php/config.php";
session_start();

if (isset($_POST['send'])) {
    // $user_id = $_REQUEST['user_id'];
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
    die();
} else {
    echo "Not";
}
