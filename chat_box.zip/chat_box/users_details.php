<?php
session_start();
include_once "php/config.php";

if (isset($_REQUEST['user_id'])) {
    echo "hello";
} else {
    echo "by";
    die();
}
