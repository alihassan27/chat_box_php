
var chat = {
  // (A) INIT - GET HTML ELEMENTS
  host: "ws://localhost:8080/", // @CHANGE to your own!
  name: "", // current user name
  socket: null, // websocket object
  hMsg: null, // html chat messages
  hName: null, // html set name form
  hNameSet: null, // html set name field
  hNameGo: null, // html set name submit
  hSend: null, // html send message form
  hSendTxt: null, // html send message field
  hSendGo: null, // html send message submit
  init: () => {
    //chat.click = document.getElementsByClassName("chat-box");
    chat.hMsg = document.getElementById("chat-box");
    chat.hName = document.getElementsByClassName("chat-name");
    chat.hNameSet = document.getElementById("chat-name-set");
    chat.hNameGo = document.getElementById("chat-name-go");

    
    chat.hSend = document.getElementById("chat-send");
    chat.hSendTxt = document.getElementById("chat-send-text");
    chat.hSendGo = document.getElementById("chat-send-go");

    chat.hNameGo.disabled = false;
  },

  // (B) SWAP BETWEEN SET NAME/SEND MESSAGE FORM
  //The direction property sets or returns the text direction (reading order) of an element's content.
  swap: direction => {
    if (direction) {
      //The Element.classList is a read-only property that returns
      // a live DOMTokenList collection of the class attributes of the element
      //remove("hide");Removes one or more tokens from the list
      chat.hName.classList.add("hide");
      chat.hSend.classList.remove("hide");
    } else {
      chat.hSend.classList.add("hide");
      chat.hName.classList.remove("hide");
    }
  },

  // (C) START CHAT
  start: () => {
    // (C1) SET NAME + SWAP HTML FORM
    chat.name = chat.hNameSet.value;
    chat.swap(1);
    // chat.hSendGo.disabled = true;
    chat.hName.classList.add("hide");

    // (C2) CREATE WEB SOCKET
    chat.socket = new WebSocket(chat.host);
    console.log('connection established');

    // (C3) ON OPEN - ENABLE CHAT
    chat.socket.onopen = e => chat.hSendGo.disabled = false;

    // (C4) ON CLOSE - SWAP BACK TO "SET NAME"
    chat.socket.onclose = e => chat.swap(0);

    // (C5) ON RECEIVING DATA - UPDATE HTML CHAT
    chat.socket.onmessage = e => {
      let msg = JSON.parse(e.data),
      row = document.createElement("div");
      row.className = "chat-row";
      // $obj = new Analyzer();
      // $result = $obj.getSentiment("msg.m"); 
      // console.log($result);
      
      row.innerHTML = `<div class="chat-name">${msg.n}</div><div class="chat-msg">${msg.m}</div>`;
      // console.log(msg);
      chat.hMsg.appendChild(row);
    };

    // (C6) ON ERROR
    chat.socket.onerror = e => {
      chat.swap(0);
      console.error(e);
      alert(`Failed to connect to ${chat.host}`);
    };

    return false;
  },

  // (D) SEND MESSAGE
  //The JSON.stringify() method converts a JavaScript value to a JSON string, optionally replacing values if a replacer function is specified or optionally 
  //including only the specified properties if a replacer array is specified
  send: () => {
    chat.socket.send(JSON.stringify({
      n: chat.name,
      m: chat.hSendTxt.value
    }));
    chat.hSendTxt.value = "";
    return false;
  }
};

window.onload = chat.init;